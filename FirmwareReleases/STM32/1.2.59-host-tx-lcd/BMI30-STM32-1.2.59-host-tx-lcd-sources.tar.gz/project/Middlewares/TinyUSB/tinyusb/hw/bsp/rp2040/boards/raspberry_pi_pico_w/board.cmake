set(PICO_PLATFORM rp2040)
set(PICO_BOARD pico_w)
