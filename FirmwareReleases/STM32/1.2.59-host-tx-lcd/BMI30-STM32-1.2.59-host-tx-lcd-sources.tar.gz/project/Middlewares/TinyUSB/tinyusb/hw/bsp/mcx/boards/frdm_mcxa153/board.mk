MCU_VARIANT = MCXA153
MCU_CORE = MCXA153
PORT = 0

CPU_CORE = cortex-m33-nodsp-nofp
CFLAGS += \
	-DCPU_MCXA153VLH \
	-DCFG_TUSB_MCU=OPT_MCU_MCXA15 \

JLINK_DEVICE = MCXA153
PYOCD_TARGET = MCXA153

# flash using pyocd
flash: flash-jlink
