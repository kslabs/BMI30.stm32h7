set(MCU_VARIANT LPC1769)

set(JLINK_DEVICE LPC1769)
set(PYOCD_TARGET LPC1769)
set(NXPLINK_DEVICE LPC1769:LPC1769)

set(LD_FILE_GNU ${CMAKE_CURRENT_LIST_DIR}/lpc1769.ld)

function(update_board TARGET)
  # nothing to do
endfunction()
