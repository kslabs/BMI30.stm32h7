"""Flash only the explicitly identified STM32L431CB, verify, then start debug.

The debugger start does not replace a final cold-start test without ST-Link.
"""
from pathlib import Path
import argparse
import hashlib
import json
import shutil
import struct
import subprocess

ROOT = Path(__file__).resolve().parent


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--serial', required=True, help='Explicit ST-Link serial number')
    p.add_argument('--openocd', type=Path)
    p.add_argument('--scripts', type=Path)
    args = p.parse_args()
    elf = ROOT / 'build/bmi30_xm125_gate_0.1.2.elf'
    binary = elf.with_suffix('.bin').read_bytes()
    manifest = json.loads((ROOT / 'build/build-manifest.json').read_text())
    if hashlib.sha256(binary).hexdigest() != manifest['bin_sha256']:
        raise RuntimeError('Firmware hash mismatch')
    cli = shutil.which('STM32_Programmer_CLI')
    connect = [cli, '-c', 'port=SWD', 'sn=' + args.serial, 'mode=HOTPLUG', 'freq=1000']
    identity = subprocess.run(connect, capture_output=True).stdout.decode(errors='replace')
    if 'Device ID   : 0x435' not in identity or 'Flash size  : 128 KBytes' not in identity:
        raise RuntimeError('Selected target is not STM32L431CB: ' + identity)
    subprocess.run([cli, '-c', 'port=SWD', 'sn=' + args.serial, 'mode=UR', 'freq=1000',
                    '-d', str(elf), '-v', '-rst'], check=True)
    if args.openocd:
        if not args.scripts:
            p.error('--scripts is required with --openocd')
        sp, pc = struct.unpack('<II', binary[:8])
        if not (0x20000000 < sp <= 0x20010000 and 0x08000000 < pc < 0x0801F000):
            raise RuntimeError('Unexpected vector table')
        subprocess.run([str(args.openocd), '-s', str(args.scripts), '-f', 'interface/stlink.cfg',
                        '-c', 'adapter serial ' + args.serial, '-f', 'target/stm32l4x.cfg',
                        '-c', 'init; halt; set flash_status [mrw 0x40022010]; '
                        'if {($flash_status & 0x20000) != 0} {mww 0x40022010 0x20000}; '
                        'reset run; shutdown'], check=True)


if __name__ == '__main__':
    main()
